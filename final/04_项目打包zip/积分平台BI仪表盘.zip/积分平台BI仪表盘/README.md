# 积分兑换平台 BI 仪表盘

> **项目名称**：积分兑换平台数据总览（Points BI · Command Center）
> **版本**：v4.0
> **作者**：大数据 242 班 · 吴静敏
> **类型**：商务智能（BI）综合实训项目
> **数据库**：SQL Server `BIDemo_AccumulateCoin`
> **访问地址**：`http://127.0.0.1:5000`

---

## 一、项目概述

### 1.1 业务背景

积分兑换平台是一个面向**多商家、跨品牌**的消费者积分通兑平台。消费者购买任一联盟商家的指定商品即可获得积分，积分可在平台兑换礼品。商家可通过平台发展会员，平台则积累了大量商家、会员、礼品、订单数据，亟需通过 BI 手段进行多维度统计分析。

**业务特点**（相比京东等零售积分）：
- 厂家直接给予积分（而非零售商），回馈力度大
- 跨品牌联盟（可口可乐 + 农夫山泉 + 华为 + 麦当劳 …）
- 可细化到省/市/区的消费者数据
- 涉及三态积分核算：余额 → 冻结 → 在途

### 1.2 项目目标

按指导书要求，完成 **BI 系统的核心功能**：

| 维度 | 要求 |
|------|------|
| 主题统计 | 商家、会员、礼品、订单 4 大主题 |
| 维度切片 | 商家/商品/会员/礼品/积分方式/地域/时间/小时 8 大维度 |
| 度量分析 | 商家数、会员数、订单数、订单分数、礼品数量、商家会员数 6 大度量 |
| 数据抽取 | T+1 全量 + 增量 ETL 流程 |
| 可视化 | 单页大屏，深蓝赛博立体风格 |
| 数据流转 | SQL Server 源库 → ODS → DW → 仪表盘 |

### 1.3 技术栈

| 层 | 技术选型 |
|----|----------|
| 后端框架 | Python 3.12 + Flask 3.1 |
| Web 服务器 | Flask 内置 dev server（threaded=True）|
| 数据库 | SQL Server 2019+ (BIDemo_AccumulateCoin) |
| 数据库驱动 | pyodbc 5.2（ODBC Driver 17/18）|
| 配置管理 | python-dotenv |
| 仪表盘 | ECharts 5.4.3 + echarts-wordcloud + echarts-liquidfill |
| 地图数据 | datav.aliyun.com 中国 GeoJSON（UTF-8）|
| 字体 | Manrope（数字大屏）+ Inter（正文）+ JetBrains Mono（时间）|
| ETL | 纯 SQL 存储过程（8 个 SP）|

---

## 二、目录结构

```
积分平台BI仪表盘/
├── app/
│   ├── __init__.py             # Flask 入口 + 11 个 REST API
│   ├── __main__.py             # python -m app 启动入口
│   ├── services/
│   │   ├── __init__.py
│   │   ├── db.py               # 数据库连接 + Mock 兜底
│   │   └── dashboard_service.py  # 11 个查询服务
│   ├── static/
│   │   ├── css/
│   │   │   └── style.css       # 深蓝赛博立体风格
│   │   └── js/
│   │       ├── dashboard.js    # ECharts 渲染 + 交互
│   │       ├── china.js        # 注册中国地图
│   │       └── china.json      # 34 省级 GeoJSON (582KB)
│   └── templates/
│       └── index.html          # 单页仪表盘
├── sql/
│   ├── 01_dw_schema.sql        # DW 建表（3 事实 + 8 维 + 1 预聚合）
│   ├── 02_seed_data.sql        # 测试数据生成脚本
│   └── 03_etl_procedures.sql   # 8 个 ETL 存储过程
├── docs/
│   ├── 数据模型文档.md          # DW 模型设计文档
│   └── ETL逻辑文档.md          # ETL 抽取规则文档
├── tests/
│   ├── test_app.py             # 基础 API 测试
│   └── e2e.py                  # 端到端 13/13 验证
├── start.bat                   # 一键启动（Windows）
├── stop.bat                    # 释放端口 5000
├── .env.example                # 环境配置模板
├── .env                        # 当前环境配置
├── requirements.txt            # Python 依赖
└── README.md                   # 本文档
```

---

## 三、核心功能详解

### 3.1 仪表盘 8 大区块

仪表盘为单页大屏布局，1920×1080 适配，按 3 行 grid 排布：

| 行 | 区块 | 类型 | 业务指标 |
|----|------|------|----------|
| Row 1 | 6 块 KPI | 六边形发光数字 | 商家/会员/礼品/订单/积分发放/积分消费 |
| Row 2 - 左 | 02 地域分布 | **3D 立体地图** | 8 大区 → 34 省级 + 4 渠道筛选 |
| Row 2 - 中 | 03 30 天交易趋势 | 折线+柱复合 | 订单数 / 兑换积分 / 活跃会员 |
| Row 2 - 右 | 04 礼品分类 | 环形饼图 | 8 大分类占比 |
| Row 3 - 1 | 05 兑换时段×商家对比 | 簇状柱+折线 | 24h 时段订单 + 商家榜 |
| Row 3 - 2 | 06 商家积分榜 | 横向条形 Top8 | 商家积分收入排名 |
| Row 3 - 3 | 07 积分生态健康度 | 仪表盘 | 积分发放/消费比率 |
| Row 3 - 4 | 08 实时订单流 | 滚动列表 | 最近 12 条订单 |

### 3.2 顶部通栏（v4 新增）

| 位置 | 内容 |
|------|------|
| 左 | 实时日期（年月日 + 星期）+ 实时时间（时分秒）|
| 中 | 大标题"积分兑换平台数据总览" + 副标题"POINTS · DATA OVERVIEW" |
| 右 | 4 个图标按钮：业务告警（带红色 badge=3）/ 系统消息 / 全局设置 / 退出登录 |

### 3.3 底部导航栏（v4 新增）

7 个一级菜单，点击切换 + Toast 提示：
- **首页总览**（active，当前页面）
- 商家监控
- 会员管理
- 积分ETL分析
- 兑换报表
- 告警管理
- 系统管理

### 3.4 地图模块（v4 升级）

| 元素 | 说明 |
|------|------|
| 主图 | 3D 立体分层 + 蓝色发光轮廓（冰蓝渐变）|
| 视觉 | 深蓝 → 浅青蓝发光色阶（visualMap）|
| 侧边栏 | 4 项竖向筛选：全部渠道 / 线下商家 / 线上商城 / 积分设备 |
| 弹窗 | 悬浮地图区域弹出，显示商家数 / 活跃会员 / 积分发放 |

### 3.5 视觉风格

**避开** AI 默认三件套（深色荧光 / 米色陶土 / 报刊 hairline），采用**深蓝赛博立体**风格：

| 元素 | 取值 |
|------|------|
| 页面底色 | `#040b1c` 深黑 + 蓝色星云暗纹 |
| 卡片背景 | `rgba(8,24,56,0.55)` 半透明深蓝渐变 |
| 卡片描边 | `#00d9ff` 冰蓝发光 + 蓝色外发光光晕 |
| 卡片四角 | 10×10 角装饰，模仿科技仪表 |
| 主色 | `#00e6ff` 冰蓝 + `#7862ff` 浅紫 + `#00ff9d` 增长绿 |
| 文字 | `#c4e2ff` 浅冰蓝（标题）/ `#94c8ff` 淡浅蓝（辅文）|
| 大数字 | `#00e6ff` 冰蓝 + 发光阴影 |
| 字体 | Manrope 800（数字）+ Inter（正文）+ JetBrains Mono（时间）|

### 3.6 自动刷新

- 前端每 30 秒调用 `/api/all` 重渲染所有图表
- 顶部"DATA STREAM"指示灯（绿色脉冲）+ 倒计时"NEXT SYNC 30s"
- 数字滚动加载动画（800ms 缓动）
- 地图/弹窗交互（hover 高亮发光）

---

## 四、数据库与数据模型

### 4.1 源数据库

源库：`BIDemo_AccumulateCoin`（即"积分平台"），共 16 张业务表 + 7 个存储过程。

| 业务表 | 用途 | 关键字段 |
|--------|------|----------|
| `BusinessMen` | 商家主表 | BusinessID, BusinessCnName, BusinessStatus |
| `CustomerInfo` | 会员主表 | CustomerID, RealName, FromBusiness, CusStatus |
| `ProductInfo` | 商家商品 | ProductID, BusinessID, ProductCoin, ProductStatus |
| `GiftInfo` | 平台礼品 | GiftID, GiftName, GiftCategory, GfitCoin, GiftStatus |
| `JFCode` | 积分码 | JFCode, ProductID, JFStatus |
| `Account` | 积分账户 | AccountID, OwnerID, Acctype (0平台/1会员/2商家), ValidCoin |
| `AccountTradeLog` | 交易日志 | TradeLogID, JFCode, TradeType, Coin, AccountID |
| `OrderInfo` | 订单主表 | OrderID, CustomerID, OrderStatus, OrderTime, TotalCoin, DestAreaID |
| `OrderGift` | 订单礼品明细 | OrderID, GiftID, GiftNum, GiftCoin |
| `ProvinceInfo` / `CityInfo` / `AreaInfo` | 地理 | 三级（实际未用）|
| `ZoneInfo` | 大区 | ZoneID, ZoneName（实际使用）|

**Acctype 账户类型**：
- `0` = 平台账户（系统）
- `1` = 会员账户（AcctypeID = CustomerID）
- `2` = 商家负债账户（AccountID 为负数）

### 4.2 DW 数据仓库（3 事实 + 8 维 + 1 预聚合）

详见 `docs/数据模型文档.md`。核心设计：

**事实表（3 张）**：
- `Fact_Point_Earn` 积分获得事实（按 JFCode 去重）
- `Fact_Point_Exchange` 积分兑换事实（按 OrderID + GiftKey 去重）
- `Fact_Order_Daily` 订单日汇总（预聚合，加速仪表盘）

**维表（8 张）**：
- `Dim_Date` 日期维（yyyyMMdd DateKey）
- `Dim_Hour` 小时维（0-23 + 时段桶）
- `Dim_Member` 会员维
- `Dim_Merchant` 商家维
- `Dim_Product` 商品维
- `Dim_Gift` 礼品维（含 IsHotGift 标记）
- `Dim_Region` 地区维（3 级，省/市/区）
- `Dim_PointType` 积分方式维（购买/赠送/活动）

**ETL 控制表**：
- `ETL_Control` 记录每个表 LastETLTime / LastRowCount / Status

### 4.3 总线矩阵落地

按文档 2 的总线矩阵 4 主题 × 8 维度 × 6 度量 落地到事实/维表：

| 维度 \\ 度量 | 商家数 | 会员数 | 订单数 | 订单分数 | 礼品数量 | 商家会员数 |
|-------------|--------|--------|--------|----------|----------|------------|
| 商家 | Dim_Merchant | - | Fact_Order | Fact_Order | - | Fact_Point_Earn |
| 商品 | - | - | Fact_Order | Fact_Order | - | Fact_Point_Earn |
| 会员 | - | Dim_Member | Fact_Order | Fact_Order | - | - |
| 礼品 | - | - | Fact_Order | Fact_Order | Dim_Gift | - |
| 积分方式 | - | - | Fact_Order | Fact_Order | - | Fact_Point_Earn |
| 地域 | - | - | Fact_Order | Fact_Order | - | - |
| 时间 | Dim_Date | Dim_Date | Dim_Date | Dim_Date | Dim_Date | Dim_Date |
| 小时 | - | - | Dim_Hour | Dim_Hour | - | - |

---

## 五、ETL 抽取流程

详见 `docs/ETL逻辑文档.md`。8 个存储过程：

| 存储过程 | 用途 | 频率 |
|----------|------|------|
| `usp_ETL_Load_DimDate` | 填充 Dim_Date 2020-2030 | 一次性 |
| `usp_ETL_Load_DimMerchant` | 商家 MERGE 全量 | T+1 |
| `usp_ETL_Load_DimMember` | 会员 MERGE 全量 | T+1 |
| `usp_ETL_Load_DimProduct` | 商品 MERGE 全量 | T+1 |
| `usp_ETL_Load_DimGift` | 礼品 MERGE 全量 | T+1 |
| `usp_ETL_Load_DimRegion` | 地区 MERGE 全量 | T+1 |
| `usp_ETL_Load_FactEarn` | 积分获得事实 增量 | T+1 |
| `usp_ETL_Load_FactExchange` | 积分兑换事实 增量 | T+1 |
| `usp_ETL_Load_FactOrderDaily` | 订单日汇总 全量重建 | T+1 |
| `usp_ETL_LoadAll` | 一键全量（首次或修复）| 手动 |

**关键设计**：
- 维表用 `MERGE` 实现 T+1 全量同步
- 事实表用 `NOT EXISTS` 增量幂等
- DateKey 代理键（`yyyyMMdd` 格式 int）
- 缓慢变化维：Type 1 覆盖（生产可升级 Type 2）

---

## 六、API 接口

12 个 REST API + 1 个主页：

| 路径 | 方法 | 用途 | 数据源 |
|------|------|------|--------|
| `/` | GET | 仪表盘主页 | templates/index.html |
| `/api/kpi` | GET | 6 项 KPI 汇总 | BusinessMen + CustomerInfo + GiftInfo + OrderInfo + Account |
| `/api/top_merchants` | GET | Top 8 商家 | BusinessMen + AccountTradeLog |
| `/api/top_gifts` | GET | Top 10 礼品 | GiftInfo + OrderGift + OrderInfo |
| `/api/trend` | GET | 30 天趋势 | OrderInfo.OrderTime |
| `/api/category_pie` | GET | 礼品分类占比 | GiftInfo.GiftCategory |
| `/api/region` | GET | 地域分布 | OrderInfo + ZoneInfo |
| `/api/hourly` | GET | 24h 时段 | OrderInfo.DATEPART(HOUR) |
| `/api/order_status` | GET | 订单状态分布 | OrderInfo.OrderStatus |
| `/api/recent_orders` | GET | 最近 12 条订单 | OrderInfo + CustomerInfo + OrderGift |
| `/api/top_members` | GET | 会员积分榜 | Account + CustomerInfo |
| `/api/merchant_members` | GET | 商家会员数 | BusinessMen + CustomerInfo + AccountTradeLog |
| `/api/all` | GET | 一键全量（仪表盘用）| 11 个查询合并 |

**性能**（真实数据 13 商家 / 49999 会员 / 5 万交易）：

| 接口 | 平均耗时 |
|------|----------|
| /api/kpi | 39ms |
| /api/trend | 7ms |
| /api/top_merchants | 480ms（最大，关联 AccountTradeLog）|
| /api/all | 527ms |

---

## 七、数据库连接与容错

### 7.1 连接策略

`db.py` 中：
- **每次查询新建连接**（pyodbc 非线程安全）
- 优先使用 `ODBC Driver 17 for SQL Server`（Windows 默认驱动）
- 失败回退到 `ODBC Driver 18 for SQL Server` / `SQL Server`（旧版）
- Windows 身份验证（Trusted_Connection=yes）

### 7.2 Mock 数据兜底

SQL Server 不可用时，自动启用 Mock 模式（`db.mock_mode = True`），按 SQL 关键词匹配返回假数据：
- 10 商家 / 200 会员 / 30 礼品 / 800 订单
- 保证仪表盘在断网/无 DB 时仍可演示

### 7.3 配置 `.env`

```env
DB_DRIVER=ODBC Driver 17 for SQL Server
DB_SERVER=localhost
DB_NAME=BIDemo_AccumulateCoin
DB_TRUSTED=yes
FLASK_HOST=127.0.0.1
FLASK_PORT=5000
FLASK_DEBUG=0
```

---

## 八、启动与使用

### 8.1 一键启动

```bash
# 双击 start.bat
# 或命令行
cd "C:\Users\Administrator\Desktop\大数据242吴静敏\实训\积分平台BI仪表盘"
start.bat
```

`start.bat` 自动：
1. 切换 UTF-8 编码（避免中文乱码）
2. 检查 `.env` 文件，不存在则从 `.env.example` 复制
3. 执行 `python -m app` 启动 Flask

### 8.2 停止服务

```bash
# 双击 stop.bat
# 或命令行
stop.bat
```

`stop.bat` 自动查找并关闭占用 5000 端口的 Python 进程。

### 8.3 浏览器访问

打开 `http://127.0.0.1:5000` 即可看到仪表盘。

### 8.4 手动启动

```bash
# 安装依赖
pip install -r requirements.txt

# 启动
python -m app
# 或
set FLASK_APP=app
flask run --host=0.0.0.0 --port=5000
```

---

## 九、交互功能

| 元素 | 交互 |
|------|------|
| 顶部图标按钮 | 告警/消息/设置/退出：弹出 Toast 提示"演示版未启用" |
| 底部导航 | 点击切换 active 状态，顶部青色顶线高亮，非首页模块提示"演示版未启用" |
| 地图侧边栏 | 4 项竖向筛选：全部渠道/线下商家/线上商城/积分设备，点击切换，地图数据按比例缩放 |
| 地图区域 | hover 高亮发光，弹出多信息浮窗（商家数/活跃会员/积分发放）|
| 数字 KPI | 数字滚动动画（800ms 缓动）|
| 实时订单流 | 取消订单红色闪烁告警 |
| 自动刷新 | 30 秒一次，前端 `setInterval` |

---

## 十、交付物清单

| 类别 | 文件 | 大小 |
|------|------|------|
| 仪表盘源码 | `app/` | 53KB |
| 视觉资源 | `app/static/` | 600KB（含 china.json）|
| SQL 脚本 | `sql/01_dw_schema.sql` | 8.5KB |
| SQL 脚本 | `sql/02_seed_data.sql` | 14.5KB |
| SQL 脚本 | `sql/03_etl_procedures.sql` | 14.5KB |
| 模型文档 | `docs/数据模型文档.md` | 7.2KB |
| ETL 文档 | `docs/ETL逻辑文档.md` | 6.1KB |
| 测试脚本 | `tests/e2e.py` | 2.1KB |
| 启动脚本 | `start.bat` / `stop.bat` | 1.1KB |
| 项目说明 | `README.md` | 本文档 |
| 依赖清单 | `requirements.txt` | 48B |
| 环境配置 | `.env.example` | 146B |

---

## 十一、开发历程

### 阶段 1：6 份原始文档研读
- 实训项目说明文档 / 总线矩阵图 / 指导书附加
- BIDW 数据模型示例 1（财务域）/ 示例 2（OA 域）
- BI 数据仓库及 ETL 设计（OA 域模板）

**串联出**：
- 业务背景：厂家直接积分 vs 零售商积分的差异
- 维度建模三件套：分析主题（事实）+ 分析角度（维度）+ 度量值
- 总线矩阵：4 主题 × 8 维度 × 6 度量值的决策表
- 4 段式 ETL：抽取频率 + 数据来源 + 存在疑问 + 抽取规则

### 阶段 2：建库脚本解码
发现 `积分平台建库及初始化.sql` 是 UTF-16 编码，3.4MB；解析出 16 张业务表 + 7 个存储过程。

**关键发现**：
- 真实库名是 `BIDemo_AccumulateCoin`（不是"积分平台"）
- 业务表结构含 `AccountTradeLog`（交易日志，5 万行）、`ZoneInfo`（替代 3 级地理）
- 业务时间字段是 `OrderTime` 而非 `CreateTime`

### 阶段 3：DW 建模
按 Kimball 维度建模设计了：
- 3 张事实表（`Fact_Point_Earn` / `Fact_Point_Exchange` / `Fact_Order_Daily`）
- 8 张维表（`Dim_Date` / `Dim_Hour` / `Dim_Member` / `Dim_Merchant` / `Dim_Product` / `Dim_Gift` / `Dim_Region` / `Dim_PointType`）
- 1 张预聚合表（`Fact_Order_Daily`）
- 3 个 BI 视图（`v_Member_Account` / `v_Merchant_Account` / `v_Dashboard_KPI`）
- 1 张 ETL 控制表（`ETL_Control`）

### 阶段 4：测试数据生成
编写 480 行的 `02_seed_data.sql`，生成：
- 8 省 / 12 市 / 15 区
- 20 商家（品牌化中文名）
- 50 礼品（家电/数码/日用/美食/美妆/服饰/运动/图书 8 类）
- 60 商家商品
- 200 会员（按 20 姓氏随机生成）
- 5000 积分码
- 800 订单（近 60 天，4 种状态分布）
- 完整账户体系（Acctype=0 平台 / 1 会员 / 2 商家）

### 阶段 5：ETL 抽取脚本
8 个存储过程 + 一键全量。

### 阶段 6：Flask + ECharts 仪表盘 v1
- 6 块 KPI + 8 个图表
- 深夜蓝 + 积分金 + 编号 01-08
- Flask 13 个路由（1 主页 + 12 API）

### 阶段 7：真实数据接入
- 解决 ODBC 驱动版本问题（优先 ODBC Driver 17）
- pyodbc 非线程安全 → 改"每次查询新建连接"
- 修 SQL 兼容：改 `OrderInfo.OrderTime`、用 `ZoneInfo` 替代 `AreaInfo`
- 优化慢查询（拆分 `get_merchant_member_count` 嵌套子查询）
- 端到端验证 13/13 通过

### 阶段 8：视觉优化 v2
- 字体升级为 Manrope / Inter / JetBrains Mono 组合
- 加 grid-bg 网格 + noise 噪点 + scanline 扫描线
- 渐变描边 + 编号 01-06 sparkline
- 6 块 KPI 配 6 色渐变 + 涨跌趋势徽章

### 阶段 9：地域改中国地图 + 组合图 v3
- 下载 datav.aliyun.com 的 582KB 中国 GeoJSON
- 解决双重编码 + Flask MIME 类型问题（`application/json; charset=utf-8`）
- 删除 24h 兑换热力柱图，改为"簇状柱+折线"组合（时段订单柱 + 商家榜折线，双 Y 轴）
- 8 区块改 2 大行（地图/趋势/分类 / 组合图/商家榜/仪表/订单流）

### 阶段 10：深蓝赛博立体风 v4
- 整体配色重做：深黑底 + 冰蓝 + 紫色辅助
- 卡片加四角装饰 + 蓝色发光描边
- 标题改发光渐变文字（白→冰蓝）
- 6 块 KPI 改为六边形发光指标框
- 趋势图主色改冰蓝 + 紫色折线
- 饼图降饱和度适配深背景
- 地图加 3D 立体分层 + 蓝色发光轮廓
- 顶部加 4 个图标按钮（告警/消息/设置/退出）
- 新增底部 7 项导航栏
- 新增地图侧边栏（4 项渠道筛选）
- 新增地图 hover 弹窗（多信息）
- 修复图表渲染高度问题
- 加 Toast 提示 + 交互反馈

---

## 十二、测试

```bash
# 基础测试（所有 API 200）
python tests/test_app.py

# 端到端 13/13 验证
python tests/e2e.py
```

预期输出：
```
=== E2E 验证 ===
  [OK]  /api/kpi                200    42ms  rows=1
  [OK]  /api/trend              200     7ms  rows=30
  [OK]  /api/top_merchants      200   488ms  rows=8
  [OK]  /api/top_gifts          200     6ms  rows=10
  [OK]  /api/category_pie       200     5ms  rows=9
  [OK]  /api/region             200     5ms  rows=2
  [OK]  /api/hourly             200     5ms  rows=24
  [OK]  /api/order_status       200     3ms  rows=1
  [OK]  /api/recent_orders      200     5ms  rows=12
  [OK]  /api/top_members        200    28ms  rows=10
  [OK]  /api/merchant_members   200    62ms  rows=10
  [OK]  /api/all                200   642ms  (7049b)
  [OK]  /                       200         (8658b)

全部通过
```

---

## 十三、性能与优化建议

| 当前瓶颈 | 优化方案 |
|----------|----------|
| `top_merchants` 480ms | 给 `AccountTradeLog` 加索引 `(BusinessID, TradeType, IsCancled)` |
| `merchant_members` 62ms | 拆 2 个简单查询 + 应用层 merge（已优化）|
| `region` 数据稀疏 | 增加 ZoneInfo 区域映射（应用层补全 8 大区）|

**生产建议**：
- 用 `gunicorn` / `uwsgi` 替代 Flask dev server
- 启用 Redis 缓存热门查询（KPI、Top）
- 启用前端 CDN（ECharts、字体）
- 真实场景下加 `Flask-Caching`

---

## 十四、常见问题

| 问题 | 解决 |
|------|------|
| ODBC 驱动找不到 | 装 `ODBC Driver 17 for SQL Server` |
| SQL Server 登录失败 | 检查 Windows 身份验证是否启用 |
| 端口 5000 被占用 | 跑 `stop.bat` |
| 地图中文乱码 | 检查 `Content-Type: application/json; charset=utf-8` |
| 图表没渲染 | 检查 `.main` 高度 + 容器 `width/height:100%` |
| 启动报 "No module named app.__main__" | 确认有 `app/__main__.py` |

---

## 十五、版本历史

| 版本 | 日期 | 说明 |
|------|------|------|
| v1.0 | 2026-07-06 | 初版，Flask + ECharts 基础版 |
| v2.0 | 2026-07-06 | 视觉优化（字体升级、渐变描边、sparkline）|
| v3.0 | 2026-07-06 | 地域改中国地图 + 簇状柱折线组合图 |
| v4.0 | 2026-07-06 | **深蓝赛博立体风** + 顶部图标 + 底部导航 + 地图侧边栏 + 弹窗 |

---

## 十六、自评与展望

### 已完成
- ✅ 6 份原始文档全部研读并串联
- ✅ 业务模型 + DW 模型完整设计
- ✅ 16 张源表 + 8 维 + 3 事实 + 1 预聚合
- ✅ 8 个 ETL 存储过程（T+1 全量/增量）
- ✅ 12 个 REST API + 1 主页
- ✅ 8 区块仪表盘：地图/趋势/分类/组合图/榜单/仪表/订单流
- ✅ 真实 SQL Server 数据接入（13/13 API 通过）
- ✅ 深蓝赛博立体视觉风格
- ✅ 顶部/底部导航 + 侧边栏 + 弹窗交互
- ✅ Mock 数据兜底（断网可用）

### 后续可扩展
- 📈 接入 pymssql + pandas + APScheduler 做完整 ETL 调度
- 📈 用 FastAPI 替换 Flask（异步高性能）
- 📈 接入 pyecharts 替代 ECharts（更 Pythonic）
- 📈 加盟商深度分析（多维下钻）
- 📈 实时告警系统（消费 Kafka 业务事件）
- 📈 移动端适配（响应式布局）
- 📈 商家/会员自助分析看板

---

**© 2026 大数据 242 班 · 吴静敏 · BI 实训项目**
